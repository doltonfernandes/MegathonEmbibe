pip install -r requirements.txt
python -m textblob.download_corpora
pip install -e .