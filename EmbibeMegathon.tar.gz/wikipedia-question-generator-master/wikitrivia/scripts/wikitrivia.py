from wikitrivia.article import Article

import click
import json

@click.command()
@click.argument('titles', nargs=-1)
@click.option('--output', type=click.File('w'), help='Output to JSON file')
def generate_trivia(titles, output):

    questions = []
    article=open("input.txt","r").read()
    click.echo('Analyzing input.txt')
    article = Article(title="input.txt",title2=article)
    questions = questions + article.generate_trivia_sentences()
    ans=""
    for i in questions:
    	ans+='{"text": "' + i["question"] + '", "fibs": ["' + i["answer"] + '"]}\n'
    print(ans)

if __name__ == '__main__':
    generate_trivia()
