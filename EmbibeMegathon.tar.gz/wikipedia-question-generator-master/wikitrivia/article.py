from nltk.corpus import wordnet as wn
from textblob import TextBlob

import re
import wikipedia

class Article:

    def __init__(self, title,title2):
        self.page = wikipedia.page(title)
        self.summary = TextBlob(title2)

    def generate_trivia_sentences(self):
        sentences = self.summary.sentences

        trivia_sentences = []
        for sentence in sentences:
            trivia = self.evaluate_sentence(sentence)
            if trivia:
                trivia_sentences.append(trivia)
        return trivia_sentences

    def evaluate_sentence(self, sentence):

        tag_map = {word.lower(): tag for word, tag in sentence.tags}
        replace_nouns = []
        for word, tag in sentence.tags:
            # For now, only blank out non-proper nouns that don't appear in the article title
            if tag == 'NN' and word not in self.page.title:
                # Is it in a noun phrase? If so, blank out the last two words in that phrase
                for phrase in sentence.noun_phrases:
                    if phrase[0] == '\'':
                        # If it starts with an apostrophe, ignore it
                        # (this is a weird error that should probably
                        # be handled elsewhere)
                        break

                # If we couldn't find the word in any phrases,
                # replace it on its own
                if len(replace_nouns) == 0:
                    replace_nouns.append(word)
                break
        
        if len(replace_nouns) == 0:
            # Return none if we found no words to replace
            return None

        trivia = {
            'answer': ' '.join(replace_nouns)
        }

        # Blank out our replace words (only the first occurrence of the word in the sentence)
        replace_phrase = ' '.join(replace_nouns)
        blanks_phrase = ('______ ' * len(replace_nouns)).strip()

        expression = re.compile(re.escape(replace_phrase), re.IGNORECASE)
        sentence=str(sentence)

        trivia['question'] = sentence
        return trivia
