Run these commands:

pyvenv venv
source venv/bin/activate
./ss.sh

Put text in input.txt

run the command wikitrivia